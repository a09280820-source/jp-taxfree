# 日本購物退稅帳 — 部署說明

拍收據、選店家、自動算「同店同日未稅滿 5,000 日圓」是否可退稅、匯出 Excel。
手機網頁 APP（PWA）＋ Google Apps Script 後端，資料存在你自己的 Google Sheet 與 Drive。

```
jp-taxfree-app/
├─ backend/   Code.gs、appsscript.json   → 用家裡筆電 clasp push
└─ web/       index.html、app.js…        → 放到 GitHub Pages
```

整個設定大約 30 分鐘，依序做 A → B → C → D。

---

## A. 建立 Google 登入用的「OAuth 用戶端 ID」（免費、一次性）

1. 開 [Google Cloud Console](https://console.cloud.google.com/)，建立新專案（名稱隨意，例如 `jp-taxfree`）。
2. 左側選單找「API 和服務 → OAuth 同意畫面」（新版叫 Google Auth Platform）。
   - 使用者類型選「外部」，填應用程式名稱（例如「日本購物退稅帳」）與你的 Email。
   - **發布狀態保持「測試中」**，不用送審。
   - 在「測試使用者」加入**三個人的 Gmail**（你、雞腿、亞衿）。沒加的人無法登入。
3. 「憑證 → 建立憑證 → OAuth 用戶端 ID」，類型選「網頁應用程式」。
   - 「已授權的 JavaScript 來源」填你的 GitHub Pages 網域，例如 `https://你的帳號.github.io`（**只填網域，後面不要加路徑**）。
   - 不需要填重新導向 URI。
4. 建立後複製「用戶端 ID」（結尾是 `.apps.googleusercontent.com`），等一下要用。

> 介面名稱可能與我寫的略有差異，找功能名稱相近的選項即可。

## B. 部署後端（要用家裡筆電）

1. 到 [Google AI Studio](https://aistudio.google.com/apikey) 建立 Gemini API Key。
   **不要綁付款方式**，就停在免費版，不會被扣錢（超過免費額度只會辨識失敗，改手動輸入）。
2. 在家裡筆電的終端機：
   ```bash
   cd backend
   clasp create --type standalone --title "日本退稅收據"
   clasp push -f        # -f：用我附的 appsscript.json 覆蓋權限設定
   clasp open
   ```
3. 在開啟的 Apps Script 編輯器：上方函式選單選 **`setup`** → 執行 → 同意授權。
   執行記錄會顯示新建立的試算表網址「日本退稅收據資料庫」。
4. 打開那份試算表的 **Users** 工作表：
   - 第一列是你（自動設為管理者 `admin`，看得到全部人的收據）。
   - 把另外兩列的「（在這裡填…的 Gmail）」換成雞腿、亞衿的 Gmail（要和他們登入的 Google 帳號一樣）。
   - 想多一個人就多加一列，`role` 填 `member`。
5. 回編輯器：左側「專案設定」→「指令碼屬性」→ 新增兩個：
   | 屬性 | 值 |
   |---|---|
   | `GOOGLE_CLIENT_ID` | A 步驟複製的用戶端 ID |
   | `GEMINI_API_KEY` | 步驟 1 的 Key |

   （選填）`GEMINI_MODEL`：若 AI 辨識一直失敗，填目前免費可用的 Flash 模型名稱，例如 `gemini-2.5-flash`。程式會自動依序嘗試備用模型。
6. 部署：右上「部署 → 新增部署作業 → 網頁應用程式」
   - 執行身分：**我**
   - 誰可以存取：**所有人**（安全性靠登入驗證＋Users 名單，不是靠網址保密）
   - 複製「網頁應用程式網址」（結尾是 `/exec`）。

> 之後改了 `Code.gs`，要「部署 → 管理部署作業 → 編輯 → 新版本」才會生效。

## C. 上線網頁

1. 打開 `web/config.js`，填兩個值：
   ```js
   API_URL: '步驟 B6 的 /exec 網址',
   GOOGLE_CLIENT_ID: 'A 步驟的用戶端 ID',
   ```
2. 把 `web/` 資料夾的內容放進 GitHub repo，開 GitHub Pages（Settings → Pages，選 main 分支與 `/` 或 `/docs` 資料夾）。
   網址會是 `https://你的帳號.github.io/repo名稱/`。
3. 確認這個網域有填在 A3 的「已授權的 JavaScript 來源」。

## D. 手機安裝（每個人都要做）

1. 用手機開網頁網址，按「用 Google 登入」。
2. **iPhone**：Safari → 分享 → 「加入主畫面」。**Android**：Chrome 選單 → 「安裝應用程式」。
   一定要加到主畫面，離線資料才不容易被系統清掉。
3. 從主畫面的圖示開啟，在這個版本再登入一次（會記住）。

## 出發前測試清單（11/12 前）

- [ ] 三個人都能登入，進得去首頁
- [ ] 拍一張收據 → AI 有預填金額（沒有的話手動輸入也要能存）
- [ ] 試算表 Receipts 工作表看得到這筆、Drive 的「日本退稅收據照片」資料夾有照片
- [ ] 開飛航模式再拍一張，確認顯示「待上傳」；關掉飛航模式後自動變回「已同步」
- [ ] 設定頁匯出 Excel，用手機或電腦打開看看
- [ ] 設定頁填預算，確認超過會變紅色

## 常見問題

| 狀況 | 怎麼辦 |
|---|---|
| 沒有出現 Google 登入按鈕 | 多半是 A3 的「JavaScript 來源」網域沒填對（要和網頁網址的網域一致，含 `https://`） |
| 登入後顯示「不在允許名單」 | 把這個 Gmail 加進 Users 工作表，再重新整理 |
| 登入失敗、說應用程式未驗證 | A2 的「測試使用者」沒加到這個 Gmail |
| AI 辨識失敗 | 看訊息：額度用完就手動輸入；其他錯誤試著設定 `GEMINI_MODEL` |
| 改了後端沒變化 | 後端要「新版本」重新部署；網頁改完要重新整理兩次（Service Worker 更新） |
| 想刪掉某人的收據 | 在 Receipts 工作表把 `deleted` 欄改成 TRUE（資料不會真的消失，可以救回） |

## 注意事項

- **預估退稅是估算**：未扣退稅業者手續費，實際金額以機場海關確認與退稅業者結算為準。
- 店家清單是常見店家的預設值，**能不能退稅以店內「Tax-free」標示為準**。清單可在 Stores 工作表增修，`active` 填 FALSE 就不會顯示。
- 2026/11/1 起的新制：先付含稅價，**離境時先到機場海關確認商品**才退稅，購買日起 90 天內要出境，商品要自己帶出境（不能郵寄）。App 的「退稅清單」頁就是給你在機場對照用的。
- **不要拍護照或個資**。免費版 Gemini 可能把送出的內容用於改進產品，收據通常沒關係，但請避開含個資的畫面。
- 收據照片存在你的 Google Drive（`日本退稅收據照片` 資料夾），只有你這個帳號擁有。
- Excel 匯出的匯率是「目前設定的匯率」。想用信用卡實際匯率，可在設定頁手動填。
