/**
 * 日本退稅收據 APP — GAS 後端
 * 登入：前端用 Google 登入拿到 ID token，這裡驗證後比對 Users 工作表的允許名單。
 * 資料：Google Sheet（Users / Stores / Receipts）＋ Drive 資料夾（收據照片）。
 *
 * 第一次使用：在編輯器選 setup 執行一次（會建立試算表與資料夾），
 * 再到「專案設定 → 指令碼屬性」填 GOOGLE_CLIENT_ID、GEMINI_API_KEY。
 */

const SHEET_USERS = 'Users';
const SHEET_STORES = 'Stores';
const SHEET_RECEIPTS = 'Receipts';

const USER_HEADERS = ['email', 'name', 'role', 'budgetTWD'];
const STORE_HEADERS = ['id', 'name', 'nameJa', 'aliases', 'category', 'active'];
const RECEIPT_HEADERS = [
  'id', 'email', 'date', 'store', 'amountIncl', 'tax', 'amountExcl', 'rate',
  'note', 'photoFileId', 'packed', 'needsReview', 'deleted', 'createdAt', 'updatedAt'
];

/* ---------- 一次性設定 ---------- */

function setup() {
  const props = PropertiesService.getScriptProperties();

  let ssId = props.getProperty('SHEET_ID');
  let ss;
  if (ssId) {
    ss = SpreadsheetApp.openById(ssId);
  } else {
    ss = SpreadsheetApp.create('日本退稅收據資料庫');
    props.setProperty('SHEET_ID', ss.getId());
  }

  ensureSheet_(ss, SHEET_USERS, USER_HEADERS);
  ensureSheet_(ss, SHEET_STORES, STORE_HEADERS);
  const rs = ensureSheet_(ss, SHEET_RECEIPTS, RECEIPT_HEADERS);
  // 日期欄固定為純文字，避免被轉成日期格式
  rs.getRange(2, RECEIPT_HEADERS.indexOf('date') + 1, rs.getMaxRows() - 1, 1).setNumberFormat('@');

  // 管理者（執行 setup 的人）
  const users = ss.getSheetByName(SHEET_USERS);
  if (users.getLastRow() < 2) {
    const me = Session.getEffectiveUser().getEmail().toLowerCase();
    users.appendRow([me, '我', 'admin', 0]);
    users.appendRow(['（在這裡填雞腿的 Gmail）', '雞腿', 'member', 0]);
    users.appendRow(['（在這裡填亞衿的 Gmail）', '亞衿', 'member', 0]);
  }

  seedStores_(ss.getSheetByName(SHEET_STORES));

  if (!props.getProperty('FOLDER_ID')) {
    const folder = DriveApp.createFolder('日本退稅收據照片');
    props.setProperty('FOLDER_ID', folder.getId());
  }

  Logger.log('試算表：' + ss.getUrl());
  Logger.log('照片資料夾 ID：' + props.getProperty('FOLDER_ID'));
  Logger.log('接著請到「專案設定 → 指令碼屬性」填 GOOGLE_CLIENT_ID 與 GEMINI_API_KEY');
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) {
    // 新試算表第一張預設工作表若是空的就直接改名使用
    const first = ss.getSheets()[0];
    if (ss.getSheets().length === 1 && first.getLastRow() === 0 && first.getName() !== name &&
        [SHEET_USERS, SHEET_STORES, SHEET_RECEIPTS].indexOf(first.getName()) === -1) {
      sh = first;
      sh.setName(name);
    } else {
      sh = ss.insertSheet(name);
    }
  }
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function seedStores_(sh) {
  if (sh.getLastRow() > 1) return;
  // 名稱, 日文, 別名(逗號分隔，用來比對收據文字), 分類
  const rows = [
    ['唐吉訶德', 'ドン・キホーテ', 'donki,ドンキ,MEGAドンキ,驚安の殿堂,don quijote', '綜合量販'],
    ['松本清', 'マツモトキヨシ', 'matsukiyo,マツキヨ,matsumoto', '藥妝'],
    ['大國藥妝', 'ダイコクドラッグ', 'daikoku', '藥妝'],
    ['札幌藥妝', 'サッポロドラッグストアー', 'sapporo,サツドラ', '藥妝'],
    ['Sundrug', 'サンドラッグ', 'sundrug,サンドラッグ', '藥妝'],
    ['鶴羽 Tsuruha', 'ツルハドラッグ', 'tsuruha', '藥妝'],
    ['Cosmos', 'コスモス', 'cosmos,コスモス薬品', '藥妝'],
    ['Welcia', 'ウエルシア', 'welcia', '藥妝'],
    ['國民藥妝 Kokumin', 'コクミン', 'kokumin', '藥妝'],
    ['Bic Camera', 'ビックカメラ', 'biccamera,ビック', '電器'],
    ['Yodobashi 友都八喜', 'ヨドバシカメラ', 'yodobashi,ヨドバシ', '電器'],
    ['Edion', 'エディオン', 'edion', '電器'],
    ['UNIQLO', 'ユニクロ', 'uniqlo', '服飾雜貨'],
    ['GU', 'ジーユー', 'gu', '服飾雜貨'],
    ['無印良品 MUJI', '無印良品', 'muji', '服飾雜貨'],
    ['LOFT', 'ロフト', 'loft', '服飾雜貨'],
    ['Hands 東急手創館', 'ハンズ', 'hands,東急ハンズ,tokyu hands', '服飾雜貨'],
    ['Daiso 大創', 'ダイソー', 'daiso', '服飾雜貨'],
    ['3COINS', 'スリーコインズ', '3coins', '服飾雜貨'],
    ['阪急梅田本店', '阪急うめだ本店', '阪急,hankyu', '百貨'],
    ['大丸梅田', '大丸梅田店', '大丸,daimaru', '百貨'],
    ['LUCUA 大阪', 'ルクア大阪', 'lucua,ルクア', '百貨'],
    ['Grand Front Osaka', 'グランフロント大阪', 'grand front,グランフロント', '百貨'],
    ['HEP FIVE', 'ヘップファイブ', 'hep five,hepfive,ヘップ', '百貨']
  ];
  const out = rows.map(function (r, i) {
    return ['S' + String(i + 1).padStart(3, '0'), r[0], r[1], r[2], r[3], true];
  });
  sh.getRange(2, 1, out.length, STORE_HEADERS.length).setValues(out);
}

/* ---------- 入口 ---------- */

function doGet() {
  return ContentService.createTextOutput('OK').setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents);
    const user = authenticate_(req.token);
    const p = req.payload || {};
    let data;
    switch (req.action) {
      case 'init': data = actionInit_(user); break;
      case 'saveReceipt': data = actionSaveReceipt_(user, p); break;
      case 'deleteReceipt': data = actionDeleteReceipt_(user, p); break;
      case 'addStore': data = actionAddStore_(user, p); break;
      case 'setBudget': data = actionSetBudget_(user, p); break;
      case 'getPhoto': data = actionGetPhoto_(user, p); break;
      case 'ocr': data = actionOcr_(user, p); break;
      default: throw err_('BAD_REQUEST', '未知的動作：' + req.action);
    }
    return json_({ ok: true, data: data });
  } catch (ex) {
    return json_({ ok: false, code: ex.code || 'ERROR', message: String(ex.message || ex) });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function err_(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

/* ---------- 登入驗證 ---------- */

function authenticate_(token) {
  if (!token) throw err_('AUTH', '尚未登入');
  const cache = CacheService.getScriptCache();
  const key = 'tok_' + md5_(token);
  let email = cache.get(key);
  if (!email) {
    const res = UrlFetchApp.fetch(
      'https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(token),
      { muteHttpExceptions: true }
    );
    if (res.getResponseCode() !== 200) throw err_('AUTH', '登入已過期，請重新登入');
    const info = JSON.parse(res.getContentText());
    if (info.aud !== prop_('GOOGLE_CLIENT_ID')) throw err_('AUTH', '登入來源不正確');
    if (String(info.email_verified) !== 'true') throw err_('AUTH', 'Google 帳號尚未驗證 Email');
    const ttl = Math.floor(Number(info.exp) - Date.now() / 1000);
    if (ttl <= 0) throw err_('AUTH', '登入已過期，請重新登入');
    email = String(info.email).toLowerCase();
    if (ttl > 10) cache.put(key, email, Math.min(300, ttl));
  }
  const user = findUser_(email);
  if (!user) throw err_('FORBIDDEN', '這個 Google 帳號不在允許名單內');
  return user;
}

function md5_(s) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, s)
    .map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}

function findUser_(email) {
  const rows = readRows_(SHEET_USERS, USER_HEADERS);
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i].email).trim().toLowerCase() === email) {
      return {
        email: email,
        name: String(rows[i].name || email),
        role: String(rows[i].role || 'member').toLowerCase() === 'admin' ? 'admin' : 'member',
        budgetTWD: Number(rows[i].budgetTWD) || 0,
        _row: rows[i]._row
      };
    }
  }
  return null;
}

/* ---------- 工作表工具 ---------- */

function prop_(k) {
  const v = PropertiesService.getScriptProperties().getProperty(k);
  if (!v) throw err_('CONFIG', '後端尚未設定 ' + k);
  return v;
}

function ss_() {
  return SpreadsheetApp.openById(prop_('SHEET_ID'));
}

function readRows_(sheetName, headers) {
  const sh = ss_().getSheetByName(sheetName);
  const last = sh.getLastRow();
  if (last < 2) return [];
  const vals = sh.getRange(2, 1, last - 1, headers.length).getValues();
  return vals.map(function (row, i) {
    const o = { _row: i + 2 };
    headers.forEach(function (h, c) { o[h] = row[c]; });
    return o;
  });
}

function dateStr_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, 'Asia/Taipei', 'yyyy-MM-dd');
  return String(v || '');
}

function receiptOut_(r, nameByEmail) {
  return {
    id: String(r.id),
    owner: String(r.email).toLowerCase(),
    ownerName: nameByEmail[String(r.email).toLowerCase()] || String(r.email),
    date: dateStr_(r.date),
    store: String(r.store),
    amountIncl: Number(r.amountIncl) || 0,
    tax: Number(r.tax) || 0,
    amountExcl: Number(r.amountExcl) || 0,
    rate: Number(r.rate) || 10,
    note: String(r.note || ''),
    photoFileId: String(r.photoFileId || ''),
    packed: r.packed === true || String(r.packed) === 'TRUE',
    needsReview: r.needsReview === true || String(r.needsReview) === 'TRUE',
    createdAt: Number(r.createdAt) || 0
  };
}

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

/* ---------- 動作 ---------- */

function actionInit_(user) {
  const users = readRows_(SHEET_USERS, USER_HEADERS);
  const nameByEmail = {};
  users.forEach(function (u) { nameByEmail[String(u.email).trim().toLowerCase()] = String(u.name); });

  const stores = readRows_(SHEET_STORES, STORE_HEADERS)
    .filter(function (s) { return s.active === true || String(s.active).toUpperCase() === 'TRUE'; })
    .map(function (s) {
      return { id: String(s.id), name: String(s.name), nameJa: String(s.nameJa || ''), aliases: String(s.aliases || ''), category: String(s.category || '其他') };
    });

  const receipts = readRows_(SHEET_RECEIPTS, RECEIPT_HEADERS)
    .filter(function (r) {
      if (r.deleted === true || String(r.deleted) === 'TRUE') return false;
      return user.role === 'admin' || String(r.email).toLowerCase() === user.email;
    })
    .map(function (r) { return receiptOut_(r, nameByEmail); });

  return {
    user: { email: user.email, name: user.name, role: user.role, budgetTWD: user.budgetTWD },
    stores: stores,
    receipts: receipts,
    users: user.role === 'admin' ? users.map(function (u) { return { email: String(u.email).toLowerCase(), name: String(u.name) }; }) : []
  };
}

function actionSaveReceipt_(user, p) {
  const r = p.receipt;
  if (!r || !r.id) throw err_('BAD_REQUEST', '缺少收據資料');

  return withLock_(function () {
    const sh = ss_().getSheetByName(SHEET_RECEIPTS);
    const rows = readRows_(SHEET_RECEIPTS, RECEIPT_HEADERS);
    let existing = null;
    for (let i = 0; i < rows.length; i++) {
      if (String(rows[i].id) === String(r.id)) { existing = rows[i]; break; }
    }
    if (existing && String(existing.email).toLowerCase() !== user.email) {
      throw err_('FORBIDDEN', '只能修改自己的收據');
    }

    let fileId = existing ? String(existing.photoFileId || '') : '';
    if (p.photoBase64 && !fileId) {
      const blob = Utilities.newBlob(Utilities.base64Decode(p.photoBase64), 'image/jpeg',
        String(r.date) + '_' + String(r.store).replace(/[\\/:*?"<>|]/g, '') + '_' + String(r.id).slice(0, 8) + '.jpg');
      fileId = DriveApp.getFolderById(prop_('FOLDER_ID')).createFile(blob).getId();
    }

    const now = Date.now();
    const line = [
      String(r.id), user.email, String(r.date), String(r.store),
      Number(r.amountIncl) || 0, Number(r.tax) || 0, Number(r.amountExcl) || 0, Number(r.rate) || 10,
      String(r.note || ''), fileId, !!r.packed, !!r.needsReview, false,
      existing ? Number(existing.createdAt) || now : (Number(r.createdAt) || now), now
    ];
    if (existing) {
      sh.getRange(existing._row, 1, 1, line.length).setValues([line]);
    } else {
      const row = sh.getLastRow() + 1;
      sh.getRange(row, RECEIPT_HEADERS.indexOf('date') + 1).setNumberFormat('@');
      sh.getRange(row, 1, 1, line.length).setValues([line]);
    }
    return { id: String(r.id), photoFileId: fileId };
  });
}

function actionDeleteReceipt_(user, p) {
  return withLock_(function () {
    const sh = ss_().getSheetByName(SHEET_RECEIPTS);
    const rows = readRows_(SHEET_RECEIPTS, RECEIPT_HEADERS);
    for (let i = 0; i < rows.length; i++) {
      if (String(rows[i].id) === String(p.id)) {
        if (String(rows[i].email).toLowerCase() !== user.email) throw err_('FORBIDDEN', '只能刪除自己的收據');
        sh.getRange(rows[i]._row, RECEIPT_HEADERS.indexOf('deleted') + 1).setValue(true);
        sh.getRange(rows[i]._row, RECEIPT_HEADERS.indexOf('updatedAt') + 1).setValue(Date.now());
        break;
      }
    }
    return { id: String(p.id) };
  });
}

function actionAddStore_(user, p) {
  const name = String(p.name || '').trim();
  if (!name) throw err_('BAD_REQUEST', '店家名稱不可空白');
  return withLock_(function () {
    const rows = readRows_(SHEET_STORES, STORE_HEADERS);
    for (let i = 0; i < rows.length; i++) {
      if (String(rows[i].name).trim().toLowerCase() === name.toLowerCase()) {
        return { id: String(rows[i].id), name: String(rows[i].name) };
      }
    }
    const id = 'S' + Utilities.getUuid().slice(0, 6);
    ss_().getSheetByName(SHEET_STORES).appendRow([id, name, '', '', String(p.category || '其他'), true]);
    return { id: id, name: name };
  });
}

function actionSetBudget_(user, p) {
  const v = Math.max(0, Number(p.budgetTWD) || 0);
  withLock_(function () {
    ss_().getSheetByName(SHEET_USERS).getRange(user._row, USER_HEADERS.indexOf('budgetTWD') + 1).setValue(v);
  });
  return { budgetTWD: v };
}

function actionGetPhoto_(user, p) {
  const rows = readRows_(SHEET_RECEIPTS, RECEIPT_HEADERS);
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i].id) === String(p.id)) {
      const owner = String(rows[i].email).toLowerCase();
      if (owner !== user.email && user.role !== 'admin') throw err_('FORBIDDEN', '沒有權限');
      const fid = String(rows[i].photoFileId || '');
      if (!fid) throw err_('NOT_FOUND', '這張收據沒有照片');
      const blob = DriveApp.getFileById(fid).getBlob();
      return { base64: Utilities.base64Encode(blob.getBytes()), mime: blob.getContentType() };
    }
  }
  throw err_('NOT_FOUND', '找不到收據');
}

/* ---------- Gemini 收據辨識 ---------- */

function actionOcr_(user, p) {
  if (!p.photoBase64) throw err_('BAD_REQUEST', '缺少照片');
  const key = prop_('GEMINI_API_KEY');
  const custom = PropertiesService.getScriptProperties().getProperty('GEMINI_MODEL');
  const models = [];
  [custom, 'gemini-3.8-flash', 'gemini-2.5-flash'].forEach(function (m) {
    if (m && models.indexOf(m) === -1) models.push(m);
  });

  const prompt =
    '這是一張日本購物收據的照片。請只輸出 JSON，格式如下，讀不到的欄位填 null：\n' +
    '{"store":"店名（收據上的原文）","date":"YYYY-MM-DD（令和請換算成西元）",' +
    '"totalIncl":含稅合計金額（日圓整數，收據上的「合計」「税込合計」）,' +
    '"tax":消費稅額（日圓整數，收據上的「内消費税」；若 8% 與 10% 分開列出就相加）,' +
    '"rate":主要稅率（10 或 8 的整數）}\n' +
    '不要輸出任何說明文字。';

  const body = {
    contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: 'image/jpeg', data: p.photoBase64 } }] }],
    generationConfig: { temperature: 0, responseMimeType: 'application/json' }
  };

  let lastMsg = '';
  for (let i = 0; i < models.length; i++) {
    const res = UrlFetchApp.fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/' + models[i] + ':generateContent',
      {
        method: 'post', contentType: 'application/json',
        headers: { 'x-goog-api-key': key },
        payload: JSON.stringify(body), muteHttpExceptions: true
      }
    );
    const code = res.getResponseCode();
    if (code === 200) {
      const j = JSON.parse(res.getContentText());
      const text = (((j.candidates || [])[0] || {}).content || {}).parts;
      const raw = text && text[0] && text[0].text ? text[0].text : '';
      const parsed = JSON.parse(raw.replace(/^```json\s*|```$/g, '').trim());
      return {
        store: parsed.store || null,
        date: parsed.date || null,
        totalIncl: parsed.totalIncl == null ? null : Math.round(Number(parsed.totalIncl)),
        tax: parsed.tax == null ? null : Math.round(Number(parsed.tax)),
        rate: parsed.rate == null ? null : Number(parsed.rate),
        model: models[i]
      };
    }
    lastMsg = res.getContentText().slice(0, 200);
    if (code === 429) throw err_('OCR_LIMIT', '今天的免費辨識額度用完了，請手動輸入金額');
    // 其他錯誤（例如模型名稱不存在）就換下一個模型
  }
  throw err_('OCR_FAIL', '辨識失敗：' + lastMsg);
}
